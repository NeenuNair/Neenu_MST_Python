from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder='templates')
app.secret_key = 'abc@123' 


def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Neenz_30@88$",
            database="recipehub",
            use_pure=True
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None


def close_db_connection(connection, cursor):
    if cursor:
        cursor.close()
    if connection:
        connection.close()

@app.route('/')
def home():
    category = request.args.get('category')  
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)
            query = '''
                SELECT r.*, u.username 
                FROM recipes r
                JOIN users u ON r.user_id = u.id
            '''
            if category:
                query += " WHERE r.category = %s"
                cursor.execute(query, (category,))
            else:
                cursor.execute(query)
            
            recipes = cursor.fetchall()
            return render_template('home.html', recipes=recipes)

    except Error as e:
        flash(f"Error fetching recipes: {e}", 'danger')
        return render_template('home.html', recipes=[])

    finally:
        close_db_connection(connection, cursor)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')

        if not username or not email or not password:
            flash('All fields are required!', 'danger')
            return redirect(url_for('register'))

        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return redirect(url_for('register'))

        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor(dictionary=True)

                cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
                existing_user = cursor.fetchone()

                if existing_user:
                    flash('Email is already registered.', 'warning')
                    return redirect(url_for('login'))

                hashed_password = generate_password_hash(password)

                cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                               (username, email, hashed_password))
                connection.commit()

                flash('Registration successful!', 'success')
                return redirect(url_for('login'))

        except Error as e:
            flash(f"Database error: {e}", 'danger')

        finally:
            close_db_connection(connection, cursor)

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            flash('All fields are required!', 'danger')
            return redirect(url_for('login'))

        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor(dictionary=True)
                cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
                user = cursor.fetchone()

                if user and check_password_hash(user['password'], password):
                    session['user_id'] = user['id']
                    session['username'] = user['username']
                    flash('Login successful!', 'success')
                    return redirect(url_for('home'))
                else:
                    flash('Invalid email or password.', 'danger')

        except Error as e:
            flash(f"Database error: {e}", 'danger')

        finally:
            close_db_connection(connection, cursor)

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()  
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('home')) 


@app.route('/submit-recipe', methods=['GET', 'POST'])
def submit_recipe():
    if request.method == 'POST':
        
        if not session.get('user_id'):
            flash('You must be logged in to submit a recipe!', 'danger')
            return redirect(url_for('login'))

        
        name = request.form['name']
        ingredients = request.form['ingredients']
        instructions = request.form['instructions']
        cooking_time = request.form['cooking_time']
        serving_size = request.form['serving_size']
        category = request.form['category']
        user_id = session.get('user_id')  

        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()

                # Insert the recipe into the database
                cursor.execute(''' 
                    INSERT INTO recipes (name, ingredients, instructions, cooking_time, serving_size, category, user_id)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                ''', (name, ingredients, instructions, cooking_time, serving_size, category, user_id))

                connection.commit()

                flash('Recipe submitted successfully!', 'success')
                return redirect(url_for('home'))  # Redirect to the home page

        except Error as e:
            flash(f"Error submitting recipe: {e}", 'danger')
            return redirect(url_for('submit_recipe'))

        finally:
            close_db_connection(connection, cursor)

    return render_template('submit_recipe.html')


@app.route('/recipe/<int:recipe_id>', methods=['GET', 'POST'])
def recipe_detail(recipe_id):
    if request.method == 'POST':
        if not session.get('user_id'):
            flash('You must be logged in to leave a comment!', 'danger')
            return redirect(url_for('login'))

        comment = request.form['comment']
        if not comment:
            flash('Comment cannot be empty!', 'danger')
            return redirect(url_for('recipe_detail', recipe_id=recipe_id))

        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(''' 
                    INSERT INTO comments (user_id, recipe_id, comment) 
                    VALUES (%s, %s, %s)
                ''', (session.get('user_id'), recipe_id, comment))

                connection.commit()
                flash('Comment added successfully!', 'success')
                return redirect(url_for('recipe_detail', recipe_id=recipe_id))

        except Error as e:
            flash(f"Error submitting comment: {e}", 'danger')
            return redirect(url_for('recipe_detail', recipe_id=recipe_id))

        finally:
            close_db_connection(connection, cursor)

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)

            cursor.execute('''
                SELECT r.*, u.username
                FROM recipes r
                JOIN users u ON r.user_id = u.id
                WHERE r.id = %s
            ''', (recipe_id,))
            recipe = cursor.fetchone()

            if recipe:
                cursor.execute(''' 
                    SELECT c.comment, u.username, c.date_posted
                    FROM comments c
                    JOIN users u ON c.user_id = u.id
                    WHERE c.recipe_id = %s
                    ORDER BY c.date_posted DESC
                ''', (recipe_id,))
                comments = cursor.fetchall()

                return render_template('recipe_details.html', recipe=recipe, comments=comments)

            else:
                flash('Recipe not found.', 'danger')
                return redirect(url_for('home'))

    except Error as e:
        flash(f"Error fetching recipe details: {e}", 'danger')
        return redirect(url_for('home'))

    finally:
        close_db_connection(connection, cursor)


if __name__ == '__main__':
    app.run(debug=True)
